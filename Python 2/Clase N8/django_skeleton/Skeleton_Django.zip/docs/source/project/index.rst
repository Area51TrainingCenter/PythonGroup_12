Introducción
============

El ``django_skeleton`` es la estructura base de todo proyecto que se
desarrollará en Wunderman Phantasia utilizando Python como lenguaje de
programación y Django como framework de backend.

