Documentación del Backend Skeleton
==================================

En estas páginas encontrarás la documentación sobre distintas funcionalidades y
módulos presentes en este proyecto:

.. toctree::
   :maxdepth: 2

   project/index
   project/install
   project/structure
   project/styleguide
   project/urls
   common/index


Índices y tablas
================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

