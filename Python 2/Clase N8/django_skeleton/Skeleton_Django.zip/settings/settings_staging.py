# coding:utf-8
from settings import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'zdacmjmq',
        'USER': 'zdacmjmq',
        'PASSWORD': 'efd3biudG2vRrS-0o0nkfV8QDniDJnVh',
        'HOST': 'raja.db.elephantsql.com',
        'PORT': '',
    },
}

DEBUG = True
BASE_URL = 'http://localhost:8000'
