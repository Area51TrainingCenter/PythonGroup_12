CREATE DATABASE users_prod;
CREATE DATABASE users_stage;
CREATE DATABASE users_dev;
CREATE DATABASE users_test;
